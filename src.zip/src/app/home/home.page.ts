import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import { NavController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { EstacionesService } from 'src/app/services/estaciones.service';
import { Subject, timer, forkJoin, from, of, defer } from 'rxjs';
import {
  finalize,
  switchMap,
  takeUntil,
  tap,
  catchError,
  timeout,
} from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomePage implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  dato: any = {};
  message: any = {};

  dia: string;
  semana: any[] = [];
  nombreMes: string;
  anio: string;
  hora: string;
  diaSemana: string;

  mensajes: any = {};
  msj: any = {};

  imagen: string;
  ubicacion: string;
  icono: string;
  uv = '';

  iconosD: any[] = [];
  maximasD: any[] = [];
  minimasD: any[] = [];
  datosH: any[] = [];

  constructor(
    private pronostico: EstacionesService,
    private router: Router,
    public loadingCtrl: LoadingController,
    public navCtrl: NavController,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    timer(0, 600000)
      .pipe(
        takeUntil(this.destroy$),
        switchMap(() => this.refreshAll())
      )
      .subscribe();
  }

  ionViewWillEnter() {
    const raw = localStorage.getItem('datos');
    if (raw) {
      this.dato = JSON.parse(raw);
      this.cargarDatos();
      this.cargarImagen();
      this.cdr.markForCheck();
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  refreshAll() {
    return defer(() => from(this.loadingCtrl.create({
      spinner: 'bubbles',
      translucent: true,
      cssClass: 'custom-class custom-loading',
      showBackdrop: false,
      message: 'Cargando...',
    }))).pipe(
      switchMap(loadingEl => {
        // Presentamos el loading
        return from(loadingEl.present()).pipe(
          switchMap(() => {
            const estacion = localStorage.getItem('estacion');

            if (!estacion || estacion === '0') {
              this.router.navigate(['/localidades']);
              return of(null);
            }

            // 1) Datos estación
            return this.pronostico.getDatos(estacion).pipe(
              timeout(12000),
              tap((posts: any) => {
                localStorage.setItem('datos', JSON.stringify(posts));
                this.dato = posts ?? {};
                this.cargarDatos();
                this.cargarImagen();
                this.cdr.markForCheck();
              }),

              // 2) Pronóstico OWM
              switchMap(() => {
                const lat = Number(this.dato?.lat);
                const lon = Number(this.dato?.lon);

                if (!lat || !lon) {
                  console.log('[HOME] Sin lat/lon, salto pronóstico');
                  return of({ clima: null, forecast: null });
                }

                console.log('[HOME] Pidiendo OWM con', lat, lon);

                return forkJoin({
                  clima: this.pronostico.getClimaActual(lat, lon).pipe(
                    timeout(12000),
                    catchError(err => {
                      console.log('[HOME] ERROR climaActual:', err);
                      return of(null);
                    })
                  ),
                  forecast: this.pronostico.getPronostico(lat, lon).pipe(
                    timeout(12000),
                    catchError(err => {
                      console.log('[HOME] ERROR pronostico:', err);
                      return of(null);
                    })
                  ),
                });
              }),

              tap(({ clima, forecast }) => {
                if (clima?.weather?.[0]?.icon) {
                  this.msj = clima;
                  this.icono = '../../assets/w-icons/' + clima.weather[0].icon + '.png';
                }

                if (forecast?.list && forecast?.cnt) {
                  this.mensajes = forecast;
                  this.datosH = this.buildDatosH(forecast);
                }

                this.cdr.markForCheck();
              }),

              catchError(err => {
                console.log('[HOME] ERROR refreshAll:', err);
                return of(null);
              }),

              finalize(() => loadingEl.dismiss().catch(() => { }))
            );
          }),
          catchError(err => {
            // Si falla el present/create del loading
            console.log('[HOME] ERROR loading:', err);
            return of(null);
          })
        );
      })
    );
  }

  refrescar(event: any) {
    this.refreshAll()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        complete: () => event?.target?.complete?.(),
        error: () => event?.target?.complete?.()
      });
  }

  cargarDatos() {
    this.semana = [];

    // dato ya asignado antes, pero lo aseguramos:
    this.dato = this.dato || this.safeParse(localStorage.getItem('datos')) || {};

    const fechaI = this.dato.fecha_I;
    if (!fechaI || typeof fechaI !== 'string' || fechaI.length < 16) return;

    this.dia = fechaI.substr(8, 2);
    const mes = fechaI.substr(5, 2);
    this.anio = fechaI.substr(0, 4);

    const dias = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'];
    const diasCortos = ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'];
    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

    const dt = new Date(`${mes} ${this.dia}, ${this.anio}`);
    this.diaSemana = dias[dt.getUTCDay()];
    this.nombreMes = meses[parseInt(mes, 10) - 1];

    for (let i = dt.getUTCDay() + 1; i < dt.getUTCDay() + 8; i++) {
      if (i > 6) this.semana.push(diasCortos[i - 7]);
      else this.semana.push(diasCortos[i]);
    }

    this.hora = fechaI.substr(11, 5);

    // Normalizaciones (sin reventar si vienen null/string raro)
    this.dato.temp_af = Number(this.dato.temp_af);
    this.dato.hum_af = Math.round(parseInt(this.dato.hum_af, 10));
    this.dato.presion = Math.round(parseInt(this.dato.presion, 10));
    this.dato.RR_dia = Math.round(parseInt(this.dato.RR_dia, 10));
    this.dato.rr_15 = parseFloat(this.dato.rr_15);
    this.dato.viento_max = Math.round(parseInt(this.dato.viento_max, 10));
  }

  onClick() {
    this.router.navigate(['/localidades']);
  }

  cargarImagen() {
    if (!this.dato) return;

    if (this.dato.temp_af < 30) {
      if (this.dato.temp_af < 0) {
        this.imagen = '../../assets/fondos/inicio-heladas.jpg';
      } else {
        this.imagen = '../../assets/fondos/inicio-soleado.jpg';
      }
    } else {
      this.imagen = '../../assets/fondos/inicio-temperatura-alta.jpg';
    }

    if (this.dato.RR_dia > 1) {
      this.imagen = '../../assets/fondos/inicio-rr.jpg';
    }

    this.ubicacion = '../../assets/wheater-icons/ubicacion.png';
  }

  private buildDatosH(mensajes: any): any[] {
    const out: any[] = [];
    let ban = 0;

    for (let i = 1; i < mensajes.cnt; i++) {
      const dt = new Date(mensajes.list[i].dt * 1000);
      const fecha = dt.getDate();

      const utcDay = dt.getUTCDate();
      const utcMonth = dt.getUTCMonth() + 1;
      const utcYear = dt.getUTCFullYear();
      const formattedDate = `${utcDay.toString().padStart(2, '0')}/${utcMonth
        .toString()
        .padStart(2, '0')}/${utcYear}`;

      if (ban !== fecha) {
        ban = fecha;
        out.push([formattedDate, 0, 0, 0, 0, 0]);
      }

      out.push([
        0,
        dt.getHours() + ':00',
        '../../assets/w-icons/' + mensajes.list[i].weather[0].icon + '.png',
        mensajes.list[i].main.temp.toFixed(0),
        mensajes.list[i].main.humidity.toFixed(0),
        (mensajes.list[i].wind.speed * 3.6).toFixed(0),
        mensajes.list[i].weather[0].description,
      ]);
    }

    return out;
  }

  private safeParse(value: string | null) {
    if (!value) return null;
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }
}
