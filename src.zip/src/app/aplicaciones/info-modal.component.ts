import { Component, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-info-modal',
  template: `
  <ion-header class="ion-no-border">
    <ion-toolbar>
      <ion-title>{{ title }}</ion-title>
      <ion-buttons slot="end">
        <ion-button (click)="close()">
          <ion-icon name="close-outline" slot="icon-only"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <ion-content class="aplicaciones contenido grad">
    <div class="content">
      <ion-card class="glass">
        <ion-card-content>
          <ion-list lines="none" class="list-compact">
            <ion-item class="advice-item" *ngFor="let p of body">
              <ion-icon name="information-circle-outline" slot="start"></ion-icon>
              <ion-label class="ion-text-wrap advice-label">{{ p }}</ion-label>
            </ion-item>
          </ion-list>
        </ion-card-content>
      </ion-card>
    </div>
  </ion-content>
  `
})
export class InfoModalComponent {
  @Input() title = '';
  @Input() body: string[] = [];

  constructor(private modalCtrl: ModalController) {}

  close() {
    this.modalCtrl.dismiss();
  }
}
